samples with names
